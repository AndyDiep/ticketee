require 'action_view/helpers/dynamic_form'

class ActionView::Base
  include DynamicForm
end
